#include<stdio.h>
#include<stdlib.h>
#include<conio.h> 
#include<windows.h>
#include<time.h>

#define WIDTH 30
#define HEIGHT 15

int snakeX[100],snakeY[100];
int snakeLength = 3;
int foodX , foodY; 
int direction = 2;
int score = 0;
int gameover = 0;

void gotoxy(int x , int y)
{
	COORD coord = {x , y};
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

void hideCursor()
{
	CONSOLE_CURSOR_INFO cursor = {1 ,0};
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor);
}

void setup()
{
	snakeX[0] = WIDTH/2;
	snakeY[0] = HEIGHT/2;
	snakeX[1] = WIDTH/2 - 1;
	snakeY[1] = HEIGHT/2;
	snakeX[2] = WIDTH/2 - 2;
	snakeY[2] = HEIGHT/2;
	
	srand(time(NULL));
	foodX = rand() % (WIDTH - 2) + 1;
	foodY = rand() % (HEIGHT - 2) + 1;
}

void  draw()
{
	system("cls");
	for(int i = 0;i <= WIDTH;i++)
	{
		gotoxy(i, 0);
		printf("#");
	}
	for(int i = 0;i <= WIDTH;i++)
	{
		gotoxy(i , HEIGHT);
		printf("#");
	}
	for(int i = 0;i <= HEIGHT;i++)
	{
		gotoxy(0 , i);
		printf("#");
	}
	for(int i = 0;i <= HEIGHT;i++)
	{
		gotoxy(WIDTH , i);
		printf("#");
	}
	gotoxy(foodX , foodY);
	printf("*");
	
	for(int i = 0;i < snakeLength;i++)
	{
		gotoxy(snakeX[i] , snakeY[i]);
		if(i == 0)
		{
			printf("0");
		}else
		{
			printf("O");
		}	
	}
	gotoxy(WIDTH + 2, 2);
	printf("�÷֣�%d",score);
	gotoxy(WIDTH + 2,3);
	printf("��ESC�˳�"); 
}
void input()
{
	if(_kbhit())
	{
		char key = _getch();
		switch(key)
		{
			case'w': if(direction != 3) direction = 1;
			break;
			case'd': if(direction != 4) direction = 2;
			break;
			case's': if(direction != 1) direction = 3;
			break;
			case'a': if(direction != 2) direction = 4;
			break;
			case 27:gameover = 1;
			break;
		}
	}
}
void logic()
{
	if(snakeX[0] <= 0 || snakeX[0] >= WIDTH || snakeY[0] <= 0 || snakeY[0] >= HEIGHT)
	{
		gameover = 1;
	}
	for(int i = snakeLength - 1;i > 0;i--)
	{
		snakeX[i] = snakeX[i - 1];
		snakeY[i] = snakeY[i - 1];
	}
	switch(direction)
	{
		case 1:snakeY[0]--;
		break;
		case 2:snakeX[0]++;
		break;
		case 3:snakeY[0]++;
		break;
		case 4:snakeX[0]--;
		break;
	}
	if(snakeX[0] == foodX && snakeY[0] == foodY)
	{
		score += 10;
		snakeLength++;
		
		foodX = rand() % (WIDTH - 2) + 1;
		foodY = rand() % (HEIGHT - 2) + 1;
	 } 
	 
	 for(int i = 1;i < snakeLength;i++)
	 {
	 	if(snakeX[0] == snakeX[i] && snakeY[0] == snakeY[i])
	 	{
	 		gameover = 1;
	 		break;
		 }
	 }
}
int main(){
	hideCursor();
	setup();
	
	while(!gameover)
	{
		draw();
		input();
		logic();
		Sleep(200);
	}
	
	system("cls");
	gotoxy(WIDTH/2 - 4,HEIGHT/2);
	printf("��Ϸ������");
	gotoxy(WIDTH/2 - 5,HEIGHT/2 + 2);
	printf("�÷֣�%d",score);
	gotoxy(WIDTH/2 - 8,HEIGHT/2 + 4);
	printf("��������˳�");
	
	_getch();
	return 0; 
}
