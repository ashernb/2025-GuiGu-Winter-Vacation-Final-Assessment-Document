#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>

int main() {
    int target;
    int guess;
    int attempts;
    int maxRange;
    int choice;
    int playAgain;

    srand((unsigned int)time(NULL));

    printf("==========================================\n");
    printf("猜数字游戏 v1.0\n");
    printf("==========================================\n");

    do {
        printf("\n请选择难度：\n");
        printf("1. 简单 (1-50)\n");
        printf("2. 中等 (1-100)\n");
        printf("3. 困难 (1-200)\n");
        printf("请输入数字(1-3): ");
        scanf("%d", &choice);

        switch(choice) {
            case 1: 
                maxRange = 50; 
                break;
            case 2: 
                maxRange = 100; 
                break;
            case 3: 
                maxRange = 200; 
                break;
            default:
                printf("输入错误，默认使用中等难度\n");
                maxRange = 100;
        }

        // 生成随机数
        target = rand() % maxRange + 1;
        attempts = 0;
        
        printf("\n我已经想好了一个1-%d之间的数字！\n", maxRange);
        
        // 猜数字主循环
        do {
            printf("请输入你的猜测: ");
            scanf("%d", &guess);
            attempts++;
            
            if (guess < target) {
                printf("猜小了！再大一点\n");
            } else if (guess > target) {
                printf("猜大了！再小一点\n");
            }
        } while (guess != target);
        
        printf("\n恭喜你猜对了！\n");
        printf("数字就是 %d\n", target);
        printf("你一共猜了 %d 次\n", attempts);
        
        printf("\n再玩一次吗？(1: 是的 / 0: 退出): ");
        scanf("%d", &playAgain);
        
    } while (playAgain == 1);
    
    printf("\n感谢游玩，再见！\n");
    printf("==========================================\n");
    
    Sleep(2000);
    return 0;
}