#include<stdio.h>
int main()
{
	/*int i=1;
	while(i<=20)
	{
		printf("%d",i);
		i++;
	}*/
	//
	//
	int sum=0;
	for(int i=1;i<=100;i++)	
	{
		if(i%2==0)
		{
			sum +=i;
		}
	}	
    printf("%d",sum);
	return 0;
}
