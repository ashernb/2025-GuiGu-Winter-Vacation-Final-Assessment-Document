#include<stdio.h>
int main()
{
	int i=1;
	for(i=1;i<=100;i++)
	{
		if(i%5==0 && i%6==0)
		{
			break;
		}
		printf("%d\n",i);
	}
	return 0;
}
