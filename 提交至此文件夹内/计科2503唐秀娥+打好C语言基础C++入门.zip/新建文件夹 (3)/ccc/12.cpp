#include<math.h>
#include<stdio.h> 
int main()
{
	int n;
	double rate;
	double capital;
	double deposit;
	printf("Please enter rate,year,capital:");
	scanf("%lf,%d,%lf",&rate,&n,&capital);
	deposit=capital*pow(1+rate,n);
	printf("deposit=%f\n",deposit);
	return 0;
}
