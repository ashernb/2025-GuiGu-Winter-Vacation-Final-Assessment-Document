#include<stdio.h>
int main()
{
	float x=2.5,y=2.5,z=2.5;
	printf("These values are :\n");
	printf("x=%f\n", x);
	printf("y=%f\n", y);
	printf("z=%f\n", z);
	return 0;
}
