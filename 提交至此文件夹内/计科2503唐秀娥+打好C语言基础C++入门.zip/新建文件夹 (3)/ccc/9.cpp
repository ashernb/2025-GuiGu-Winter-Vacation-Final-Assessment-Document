#include<stdio.h>
int main()
{
	//int x=5-22;
	int num=5;
	printf("%d\n",num*4);
	return 0;
}
