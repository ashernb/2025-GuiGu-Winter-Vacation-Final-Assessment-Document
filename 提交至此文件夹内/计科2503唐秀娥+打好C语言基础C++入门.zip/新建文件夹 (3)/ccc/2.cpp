#include<stdio.h>
int main()
{
	/*int num1=3;
	int num2=5;
	printf("%d\n",num1&num2);
	printf("%d\n",num1|num2);
	printf("%d\n",num1^num2);
	printf("%d\n",~0);*/
	
	/*int a;
	int b;
	scanf("%d %d",&a,&b);
	int m=a/b;
	int n=a%b;
	printf("%d %d\n",m,n);*/
	
	
	/*int n;
	scanf("%d",&n);
	if(n%2!=0)
	{
      printf("%d is ����\n",n);
    }
    else
    {
    	printf("%d is ż��\n",n);
	}*/
	
	
	int m;
	scanf("%d",&m);
	if(m>=18)
	{
		printf("����\n",m);
	}
	else
	{
		printf("δ����\n",m);
	}
	

	
	return 0;
}

