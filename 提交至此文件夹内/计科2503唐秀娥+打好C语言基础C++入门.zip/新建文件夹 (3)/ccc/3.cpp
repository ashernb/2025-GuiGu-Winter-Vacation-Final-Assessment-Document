#include<stdio.h>
int main()
{
	int i=10;
	int arr1[5]={1,2,3,4,5};
	int arr2[3][3]={{1,2,3},{4,5,6},{7,8,9}};
	for(i=0;i<5;i++)
	{
		printf("%d",arr1[i]);
	}
	for(i=0;i<3;i++)
	{
	for(int j=0;j<3;j++)
	{
		printf("%d",arr2[i][j]);
	}
   }
   return 0;
}
