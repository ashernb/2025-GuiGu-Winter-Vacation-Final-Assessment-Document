#include<stdio.h> 
int main()
{
	int a,b,sum;
	a=11;
	b=11;
	sum=a+b;
	printf("sum is %d\n",sum);
	return 0;
}
