#include<stdio.h>
int main()
{
	int a;
	scanf("a=%d",&a);
	printf("a=%d\n",a);
	return 0;
}
