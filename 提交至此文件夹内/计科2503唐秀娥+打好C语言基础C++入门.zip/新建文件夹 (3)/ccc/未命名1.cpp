/*#include<stdio.h>
int main()
{
	int n=1;
	while(n>=1&&n<=100)
	{
		if(n%2==0 && n%3!=0)
		{
			printf("%d\n",n);
		}
		n++; 
	}
	return 0;
}*/ 

/*#include<stdio.h>
int main()
{
	int n;
	for(n=1;n<=100;n++)
	{
		if(n%2==0&&n%3!=0)
		printf("%d\n",n);
	}
	return 0;
}*/
/*#include<stdio.h>
int main()
{
	int k,sum=0;
	printf("������k��ֵ:") ;
	scanf("%d",&k); 
	for(int i=1;i<k;i++)
	{
		if(i%2==0)
		{
			sum+=i;
		}
	}
	printf("��Ϊ��%d\n",sum);
	return 0;
}*/
/*#include<stdio.h>
int main()
{
	int m;
	scanf("%d",&m);
	int sum=0,sign=1;
	for(int i=2;i<=m;i+=2)
	{
		sum+=sign*i;
		sign=-sign;
	}
	printf("%d\n",sum);
	return 0;
}*/
/*#include<stdio.h>
int main()
{
	int n;
	int sum=0;
	for(n=0;n<=98;n+=2)
	{
		sum=sum+(n+2)*(n+3)*(n+1);
	}
	printf("%d\n",sum);
	return 0;
	
} */
#include<stdio.h>
int main()
{
    int n;
    for(n=10;n<=100;n++)
    {
    	if(n%2==0&&n%4==0&&n%7==0)
    	{
	    	printf("%d\n",n);
      	}
    }
    return 0;
}
 
